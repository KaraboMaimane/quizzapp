import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Trivia2Page } from './trivia2';

@NgModule({
  declarations: [
    Trivia2Page,
  ],
  imports: [
    IonicPageModule.forChild(Trivia2Page),
  ],
})
export class Trivia2PageModule {}
