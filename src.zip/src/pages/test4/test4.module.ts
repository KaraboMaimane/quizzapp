import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Test4Page } from './test4';

@NgModule({
  declarations: [
    Test4Page,
  ],
  imports: [
    IonicPageModule.forChild(Test4Page),
  ],
})
export class Test4PageModule {}
