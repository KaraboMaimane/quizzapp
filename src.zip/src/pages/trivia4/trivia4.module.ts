import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Trivia4Page } from './trivia4';

@NgModule({
  declarations: [
    Trivia4Page,
  ],
  imports: [
    IonicPageModule.forChild(Trivia4Page),
  ],
})
export class Trivia4PageModule {}
