import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Test5Page } from './test5';

@NgModule({
  declarations: [
    Test5Page,
  ],
  imports: [
    IonicPageModule.forChild(Test5Page),
  ],
})
export class Test5PageModule {}
