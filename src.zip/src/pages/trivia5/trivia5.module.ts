import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Trivia5Page } from './trivia5';

@NgModule({
  declarations: [
    Trivia5Page,
  ],
  imports: [
    IonicPageModule.forChild(Trivia5Page),
  ],
})
export class Trivia5PageModule {}
