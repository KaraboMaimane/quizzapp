import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Loadp2Page } from './loadp2';

@NgModule({
  declarations: [
    Loadp2Page,
  ],
  imports: [
    IonicPageModule.forChild(Loadp2Page),
  ],
})
export class Loadp2PageModule {}
