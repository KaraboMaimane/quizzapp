import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Trivia3Page } from './trivia3';

@NgModule({
  declarations: [
    Trivia3Page,
  ],
  imports: [
    IonicPageModule.forChild(Trivia3Page),
  ],
})
export class Trivia3PageModule {}
