import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoadpPage } from './loadp';

@NgModule({
  declarations: [
    LoadpPage,
  ],
  imports: [
    IonicPageModule.forChild(LoadpPage),
  ],
})
export class LoadpPageModule {}
