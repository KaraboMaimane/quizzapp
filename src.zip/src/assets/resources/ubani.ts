let ubaniArray = [];
export default ubaniArray;