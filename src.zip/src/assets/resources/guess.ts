let guessArray = [];
export default guessArray;