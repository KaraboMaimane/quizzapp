let triviaArray = [];
export default triviaArray;