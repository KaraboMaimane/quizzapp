let masalaArray = [];
export default masalaArray;